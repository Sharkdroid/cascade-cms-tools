# Template index

Pick by **task shape**, copy, then edit. Every template here passes
`scripts/validate_script.py` as written — starting from one means you are
editing a known-good file instead of writing structure from memory.

```bash
python scripts/new_script.py --template create-bulk --out my_script.py
```

## Core operations

| Task shape | Template |
|---|---|
| Read specific assets by UUID and/or site+path | `read-identifiers` |
| Read the same assets repeatedly, cheaply | `read-cache` |
| Find assets by search, then read each one | `read-iterate` |
| Create many assets from a CSV or list | `create-bulk` |
| Read assets, change fields, save them back | `edit-in-place` |
| Read an asset's workflow and advance it | `workflow-orchestration` |
| Do the same work across several sites at once | `concurrent-multisite` |
| Simple task, results handled in a plain loop | `callback-none` |

## Callback patterns

| Task shape | Template |
|---|---|
| Run several transforms in order on each result | `callback-chain` |
| Handle mixed result types / tell success from failure | `callback-type-dispatch` |
| Feed results into a second, dependent batch | `callback-dependent` |
| Queue a follow-up publish based on what was read | `callback-conditional-publish` |
| Call an async API per result | `callback-async-io` |
| Combine a sync transform with an async hand-off | `callback-mixed-sync-async` |
| CPU-heavy per-asset work (parsing, hashing, images) | `callback-cpu-bound` |
| Write results to a CSV or other file | `callback-csv-export` |
| Count or collect across all results | `callback-accumulator` |
| Show progress while a long batch runs | `callback-progress-reporting` |
| Keep going when one result's processing fails | `callback-error-isolation` |
| Edit, rename, or move/reparent structured-data (data-definition) nodes | `callback-structured-data-edit` |
| Inspect page-configuration regions | `callback-page-region-audit` |

## Choosing a callback style

- **No callback** — sequential work over a small result list. Start here.
- **Sync callback** — blocking work (file I/O, `requests`, CPU). Runs in a
  `ThreadPoolExecutor` by default; pass a `ProcessPoolExecutor` for CPU-bound work.
- **Async callback** — the work is already awaitable. Awaited directly on the loop.

Shared state touched from a sync callback needs a `threading.Lock`: callbacks
run concurrently across results. A `ProcessPoolExecutor` does not share memory
at all, so accumulate in the parent instead.
