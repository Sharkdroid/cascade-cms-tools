#!/usr/bin/env python3
"""Mutate structured-data nodes in a callback, then save.

Three composable operations, in order of how much of the tree they touch:

1. Field edit (update_contact) — get_data_structure(group, identifier)
   returns matching leaf nodes BY REFERENCE, so mutating a returned node
   mutates the asset itself.
2. Rename (rename_node) — same lookup, then reassign the node's own
   "identifier" key. No parent reference needed.
3. Move/reparent (move_node) — Asset.get_data_structure() is leaf-only and
   gives no reference to a node's *parent* container, so relocating a node
   to a different group needs a locate-parent-and-splice pattern that walks
   asset._data directly: find the node's parent structuredDataNodes list
   (to detach it), find the destination group's structuredDataNodes list
   (to reattach it), then move the dict between them.

Rename and move are independent — call one, both, or neither per node.

One chain per target: `read(identifier).edit(identifier, apply_edits)`
reads the asset, then `edit()`'s callable payload (`apply_edits`) is invoked
with that result — it mutates and returns the asset, which is what gets
saved. Nothing is sent until `submit_requests()` runs the whole batch.
"""

import os
import uuid
from typing import Any

from cascade_cms.cmstypes import Asset, CascadeError, CascadeSuccess, IdentifierType
from cascade_cms.wrapper import CascadeWrapperBase

# ----- Configuration -----
environment_variables = {
    "API_KEY": os.environ["CASCADE_API_KEY"],
    "CASCADE_URL": os.environ["CASCADE_URL"],
    "SERVER": os.environ.get("SERVER", "default"),
}
configuration_variables = {
    "cache_name": "./cache/cache.sqlite",
    "allowed_codes": (200,),
    "allowed_methods": ("GET",),
}

TARGETS = [
    IdentifierType(id=uuid.UUID("e868f539ac1001062cfa029c4c5df4d0"), type="page"),
]

GROUP = "contact-block"
FIELD = "phone"
NEW_VALUE = "+1 555 0100"

# Move/rename config — only used by move_node/rename_node below.
MOVE_SOURCE_GROUP = "contact-block"
MOVE_NODE_IDENTIFIER = "phone"
MOVE_DEST_GROUP = "secondary-contact-block"
RENAME_TO = "primary-phone"


def _find_group(node: Any, group_identifier: str) -> dict[str, Any] | None:
    """Depth-first search for a group container node by identifier, mirroring
    Asset.get_data_structure()'s own traversal (cascade_cms/cmstypes.py)."""
    if isinstance(node, dict):
        if node.get("type") == "group" and node.get("identifier") == group_identifier:
            return node
        for value in node.values():
            found = _find_group(value, group_identifier)
            if found is not None:
                return found
    elif isinstance(node, list):
        for item in node:
            found = _find_group(item, group_identifier)
            if found is not None:
                return found
    return None


def _locate_in_nodes(nodes: list[dict[str, Any]], node_identifier: str) -> tuple[list[dict[str, Any]], dict[str, Any]] | None:
    """Search one structuredDataNodes list (and its nested groups) for a leaf
    node, returning (containing_list, node) so the caller can splice it —
    Asset.get_data_structure() returns only the node, never its parent list."""
    for node in nodes:
        if "structuredDataNodes" in node:
            found = _locate_in_nodes(node["structuredDataNodes"], node_identifier)
            if found is not None:
                return found
        elif node.get("identifier") == node_identifier:
            return nodes, node
    return None


def update_contact(asset: Asset) -> Asset:
    nodes = asset.get_data_structure(GROUP, FIELD)
    for node in nodes or []:
        node["text"] = NEW_VALUE  # by-reference: edits the asset in place
    return asset


def rename_node(asset: Asset) -> Asset:
    """Change a node's own identifier — no parent reference required."""
    group_node = _find_group(asset._data, MOVE_SOURCE_GROUP)
    if group_node is None:
        return asset
    located = _locate_in_nodes(group_node["structuredDataNodes"], MOVE_NODE_IDENTIFIER)
    if located is None:
        return asset
    _, node = located
    node["identifier"] = RENAME_TO
    return asset


def move_node(asset: Asset) -> Asset:
    """Detach a node from its current parent group and reattach it under a
    different one. Reparenting only — combine with rename_node for both."""
    source_group = _find_group(asset._data, MOVE_SOURCE_GROUP)
    dest_group = _find_group(asset._data, MOVE_DEST_GROUP)
    if source_group is None or dest_group is None:
        return asset

    located = _locate_in_nodes(source_group["structuredDataNodes"], MOVE_NODE_IDENTIFIER)
    if located is None:
        return asset
    parent_list, node = located

    parent_list.remove(node)
    dest_group["structuredDataNodes"].append(node)
    return asset


def main() -> None:
    with CascadeWrapperBase(environment_variables, configuration_variables) as cascade:
        for identifier in TARGETS:
            cascade.operations.read(identifier).edit(identifier, update_contact)

        try:
            results = cascade.submit_requests(CascadeSuccess)
        except Exception as exc:
            print(f"Batch failed: {exc}")
            return

        saved = sum(1 for r in results if not isinstance(r, (CascadeError, Exception)))
        print(f"Saved {saved}.")
        for result in results:
            if isinstance(result, CascadeError):
                print(f"FAILED: {result.message}")
            elif isinstance(result, Exception):
                print(f"FAILED: {result}")


if __name__ == "__main__":
    main()
