#!/usr/bin/env python3
"""Static validator for generated cascade_cms scripts.

Checks, each gating the next:
  0. Bundle banner      - prints the bundled library version + manifest status,
                          so a stale snapshot is never silent.
  1. Syntax             - ast.parse(); catches typos, indentation, brackets.
  2. Wrapper-only       - fails on cascade_cms.driver usage, manual asyncio
                          event-loop management, or a hand-built ClientSession.
  3. Imports            - imports the real bundled package and verifies every
                          name the script imports actually exists.
  4. Operation names    - flags cascade.operations.<X> where X is not a real
                          Operations method, suggesting the closest match.
  5. Asset writes       - flags asset[...] = ... on an Asset; Asset defines
                          __setattr__, not __setitem__.
  6. Path identifiers   - flags Path dict literals missing siteName/asset_type.
  6b. Asset-type security - flags IdentifierType/NewAsset/Path construction
                          targeting a blocked asset type (user/group/role/message).
  7. Result type        - warns when submit_requests(T) disagrees with the
                          queued operation's actual return type.
  8. Construction       - re-instantiates every payload model call found in the
                          script against the real Pydantic models.
  9. Formatting         - runs `ruff format --check` against the script (150-char
                          lines, parenthesized chains); fails if ruff would
                          reformat it. Requires ruff to be installed.

Usage:
    python validate_script.py path/to/generated_script.py

Exit code 0 = all checks passed. Non-zero = see output for details.
No network calls are made at any point.
"""

import ast
import difflib
import json
import shutil
import subprocess
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
BUNDLED_PKG_PARENT = SKILL_ROOT
MANIFEST_PATH = SKILL_ROOT / "cascade_cms" / "_bundle_manifest.json"
RUFF_CONFIG_PATH = SKILL_ROOT / "ruff.toml"


def field_reference() -> str:
    """Name the field reference this bundle ships, for error messages that
    point a model at exact field names and aliases."""
    return "references/operations_schema.json"


def print_bundle_banner() -> None:
    """Level 0: surface which library version this validator actually checks
    against. Silent drift between the bundle and src/cascade_cms/ is what made
    the previous skill reject correct scripts."""
    if not MANIFEST_PATH.exists():
        print("[BUNDLE] WARNING: no _bundle_manifest.json — snapshot provenance unknown.")
        print("         Run: python skill/build_skill.py")
        return
    try:
        manifest = json.loads(MANIFEST_PATH.read_text())
    except json.JSONDecodeError as e:
        print(f"[BUNDLE] WARNING: manifest unreadable ({e}).")
        return

    version = manifest.get("library_version", "unknown")
    print(f"[BUNDLE] Validating against cascade-cms-rest {version}")

    import hashlib

    drifted = [
        name
        for name, digest in manifest.get("files", {}).items()
        if not (SKILL_ROOT / "cascade_cms" / name).exists()
        or hashlib.sha256((SKILL_ROOT / "cascade_cms" / name).read_bytes()).hexdigest()
        != digest
    ]
    if drifted:
        print(f"[BUNDLE] WARNING: {len(drifted)} bundled file(s) differ from the manifest:")
        for name in drifted:
            print(f"           - {name}")
        print("         Rebuild with: python skill/build_skill.py")


def check_syntax(source: str, path: str) -> ast.Module:
    """Level 1: parse the file. Raises SyntaxError with line info on failure."""
    try:
        tree = ast.parse(source, filename=path)
    except SyntaxError as e:
        print(f"[SYNTAX ERROR] {path}:{e.lineno}:{e.offset}: {e.msg}")
        sys.exit(1)
    print("[OK] Syntax check passed")
    return tree


FORBIDDEN_DRIVER_NAMES = {
    "CascadeCMSRestDriver",
    "RequestExecutor",
    "CacheHandler",
    "DEFAULT_CACHECONFIG",
}

# Attribute/call names indicating manual loop/session management. Checked as
# the called attribute name rather than a specific import alias, so this still
# catches `import asyncio as aio; aio.new_event_loop()`.
FORBIDDEN_LOOP_SESSION_CALLS = {
    "new_event_loop": "creates a raw event loop — CascadeWrapperBase owns the loop for the session's lifetime",
    "set_event_loop": "reassigns the running event loop — CascadeWrapperBase already does this internally",
    "run_until_complete": "drives the loop manually — use cascade.submit_requests() instead",
    "get_event_loop": "reaches for the loop directly — not needed outside the wrapper",
}
FORBIDDEN_SESSION_CONSTRUCTORS = {"ClientSession"}


def check_wrapper_only(tree: ast.Module, path: str):
    """Level 2: fail if the script touches cascade_cms.driver directly, OR
    manually manages an event loop / HTTP session. CascadeWrapperBase must be
    the sole entry point — any of these bypass logger wiring, the callback
    execution path, and session/event-loop cleanup."""
    violations = []

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            if node.module == "cascade_cms.driver" or node.module.endswith(".driver"):
                names = ", ".join(a.name for a in node.names)
                violations.append(
                    f"line {node.lineno}: 'from {node.module} import {names}' — "
                    f"import from cascade_cms.wrapper instead"
                )
            else:
                for alias in node.names:
                    if alias.name in FORBIDDEN_DRIVER_NAMES:
                        violations.append(
                            f"line {node.lineno}: imports '{alias.name}' directly — "
                            f"driver internals must not be used outside CascadeWrapperBase"
                        )
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "cascade_cms.driver" or alias.name.endswith(".driver"):
                    violations.append(
                        f"line {node.lineno}: 'import {alias.name}' — "
                        f"scripts must not import the driver module"
                    )
        if isinstance(node, ast.Name) and node.id in FORBIDDEN_DRIVER_NAMES:
            violations.append(f"line {node.lineno}: references '{node.id}' directly")
        if isinstance(node, ast.Attribute) and node.attr in FORBIDDEN_DRIVER_NAMES:
            violations.append(f"line {node.lineno}: references '.{node.attr}' directly")

        if isinstance(node, ast.Call):
            called_name = None
            if isinstance(node.func, ast.Attribute):
                called_name = node.func.attr
            elif isinstance(node.func, ast.Name):
                called_name = node.func.id
            if called_name in FORBIDDEN_LOOP_SESSION_CALLS:
                reason = FORBIDDEN_LOOP_SESSION_CALLS[called_name]
                violations.append(f"line {node.lineno}: calls '{called_name}()' — {reason}")
            if called_name in FORBIDDEN_SESSION_CONSTRUCTORS:
                violations.append(
                    f"line {node.lineno}: constructs '{called_name}(...)' directly — "
                    f"CascadeWrapperBase/driver owns the HTTP session; scripts should never open their own"
                )

    if violations:
        print("[WRAPPER-ONLY ERROR] Script bypasses CascadeWrapperBase:")
        for v in sorted(set(violations)):
            print(f"  - {v}")
        print("  Fix: use only CascadeWrapperBase + cascade.operations.<op>(...) + cascade.submit_requests(...)")
        sys.exit(1)
    print("[OK] Wrapper-only check passed — no direct driver usage")


def _load_modules():
    sys.path.insert(0, str(BUNDLED_PKG_PARENT))
    try:
        import cascade_cms.cmstypes as cmstypes
        import cascade_cms.driver as driver
        import cascade_cms.operations as operations
        import cascade_cms.wrapper as wrapper
    except Exception as e:
        print(f"[IMPORT ERROR] Could not import bundled cascade_cms package: {e}")
        sys.exit(1)
    return {
        "cascade_cms.cmstypes": cmstypes,
        "cascade_cms.operations": operations,
        "cascade_cms.wrapper": wrapper,
        "cascade_cms.driver": driver,
    }


def check_imports(tree: ast.Module, source_path: str):
    """Level 3: import cascade_cms for real and verify every name the script
    imports from it actually exists (catches renamed/misspelled symbols)."""
    modules = _load_modules()

    missing = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("cascade_cms"):
            mod = modules.get(node.module)
            if mod is None:
                continue
            for alias in node.names:
                if alias.name == "*":
                    continue
                if not hasattr(mod, alias.name):
                    candidates = difflib.get_close_matches(
                        alias.name, [n for n in dir(mod) if not n.startswith("_")], n=3
                    )
                    hint = f" Did you mean: {', '.join(candidates)}?" if candidates else ""
                    missing.append(f"{node.module}.{alias.name} (line {node.lineno}).{hint}")

    if missing:
        print("[IMPORT ERROR] The following imported names do not exist in cascade_cms:")
        for m in missing:
            print(f"  - {m}")
        print("  Fix: correct the name, or read cascade_cms/cmstypes.py for the real symbol.")
        sys.exit(1)
    print("[OK] Import check passed — all cascade_cms references are real")


def check_operation_names(tree: ast.Module):
    """Level 4: flag cascade.operations.<X>(...) where X is not a real
    Operations method. A typo here otherwise fails only at runtime, after
    the script has already authenticated against a live server."""
    modules = _load_modules()
    operations_cls = modules["cascade_cms.operations"].Operations
    valid = {n for n in dir(operations_cls) if not n.startswith("_")}

    bad = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
            continue
        inner = node.func.value
        # match `<anything>.operations.<method>(...)`
        if isinstance(inner, ast.Attribute) and inner.attr == "operations":
            name = node.func.attr
            if name not in valid:
                candidates = difflib.get_close_matches(name, sorted(valid), n=3)
                hint = (
                    f" Did you mean: {', '.join(candidates)}?"
                    if candidates
                    else f" Valid operations: {', '.join(sorted(valid))}"
                )
                bad.append(f"line {node.lineno}: cascade.operations.{name}(...) does not exist.{hint}")

    if bad:
        print("[OPERATION ERROR] Unknown Operations method(s):")
        for b in bad:
            print(f"  - {b}")
        sys.exit(1)
    print("[OK] Operation-name check passed")


def check_asset_subscript_assignment(tree: ast.Module):
    """Level 5: flag `asset[...] = ...` where the target is an Asset.

    Asset is dict-*backed* but not dict-*like* for writes: it defines
    __setattr__ and .get(), and no __setitem__ at all, so subscript assignment
    raises TypeError at runtime. Published wiki examples get this wrong.
    """
    asset_names = set()

    for node in ast.walk(tree):
        # def cb(asset: Asset) / def cb(a: "Asset")
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for arg in list(node.args.args) + list(node.args.kwonlyargs):
                ann = arg.annotation
                if isinstance(ann, ast.Name) and ann.id == "Asset":
                    asset_names.add(arg.arg)
                elif isinstance(ann, ast.Constant) and ann.value == "Asset":
                    asset_names.add(arg.arg)
        # x: Asset = ...
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            ann = node.annotation
            if (isinstance(ann, ast.Name) and ann.id == "Asset") or (
                isinstance(ann, ast.Constant) and ann.value == "Asset"
            ):
                asset_names.add(node.target.id)
        # x = Asset(...)
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            func = node.value.func
            if isinstance(func, ast.Name) and func.id == "Asset":
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        asset_names.add(target.id)
        # for asset in <...>: with isinstance(x, Asset) guard is not tracked —
        # annotation-based detection only, to avoid false positives on dicts.

    violations = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if (
                isinstance(target, ast.Subscript)
                and isinstance(target.value, ast.Name)
                and target.value.id in asset_names
            ):
                key = ""
                if isinstance(target.slice, ast.Constant):
                    key = str(target.slice.value)
                var = target.value.id
                suggestion = f"{var}.{key} = ..." if key.isidentifier() else f"{var}.<field> = ..."
                violations.append(
                    f"line {node.lineno}: `{var}[{key!r}] = ...` — `Asset` has no `__setitem__`. "
                    f"Use `{suggestion}` instead (Asset defines __setattr__, not __setitem__)."
                )

    if violations:
        print("[ASSET WRITE ERROR] Subscript assignment on an Asset:")
        for v in violations:
            print(f"  - {v}")
        print("  Read with asset.get('field'); write with asset.field = value.")
        sys.exit(1)
    print("[OK] Asset write check passed")


IDENTIFIER_OP_NAMES = {
    "read", "delete", "copy", "move", "publish", "checkIn", "checkOut",
    "listSubscribers", "readAccessRights", "readWorkflowSettings",
    "readWorkflowInformation", "performWorkflowTransition",
}


def _dict_literal_keys(node: ast.Dict) -> set[str]:
    return {k.value for k in node.keys if isinstance(k, ast.Constant) and isinstance(k.value, str)}


def check_path_identifiers(tree: ast.Module):
    """Level 6: a Path identifier is a plain dict, so nothing validates it
    until resolve_identifier() raises at request-build time. Require the two
    keys it actually needs."""
    violations = []

    def inspect(d: ast.Dict, lineno: int, where: str):
        keys = _dict_literal_keys(d)
        if not keys or "path" not in keys:
            return  # not a Path-shaped literal
        if "siteName" not in keys:
            violations.append(
                f"line {lineno}: {where} Path dict has 'path' but no 'siteName' — "
                f"resolve_identifier() raises ValueError('Path identifiers require siteName "
                f"to build the request URL'). Add siteName='<site>'."
            )
        if "asset_type" not in keys:
            violations.append(
                f"line {lineno}: {where} Path dict is missing 'asset_type' (e.g. 'page', "
                f"'file', 'folder') — required to build the request URL."
            )

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            inner = node.func.value
            if isinstance(inner, ast.Attribute) and inner.attr == "operations":
                if node.func.attr not in IDENTIFIER_OP_NAMES:
                    continue
                for arg in node.args[:1]:
                    if isinstance(arg, ast.Dict):
                        inspect(arg, node.lineno, f"cascade.operations.{node.func.attr}(...)")
                    elif isinstance(arg, (ast.List, ast.Tuple)):
                        for elt in arg.elts:
                            if isinstance(elt, ast.Dict):
                                inspect(elt, node.lineno, f"cascade.operations.{node.func.attr}(...)")
        # standalone `ident: Path = {...}`
        if isinstance(node, ast.AnnAssign) and isinstance(node.value, ast.Dict):
            ann = node.annotation
            if isinstance(ann, ast.Name) and ann.id == "Path":
                inspect(node.value, node.lineno, "Path annotation")

    if violations:
        print("[PATH IDENTIFIER ERROR] Malformed Path identifier(s):")
        for v in violations:
            print(f"  - {v}")
        sys.exit(1)
    print("[OK] Path identifier check passed")


SECURITY_GATE_PATH = SKILL_ROOT / "references" / "blocked_asset_types.json"

# Constructor names whose `asset_type`/`type` keyword (or, for a Path dict
# literal, its "asset_type" key) names the asset type being targeted.
ASSET_TYPE_CONSTRUCTORS = {"IdentifierType": {"type", "asset_type"}, "NewAsset": {"asset_type"}}


def _blocked_asset_types() -> set[str]:
    if not SECURITY_GATE_PATH.exists():
        return set()
    try:
        gate = json.loads(SECURITY_GATE_PATH.read_text())
    except json.JSONDecodeError:
        return set()
    return {t.lower() for t in gate.get("blocked", [])}


def check_asset_type_security(tree: ast.Module):
    """Level 6b: flag any IdentifierType/NewAsset/Path construction that
    targets a blocked asset type (user/group/role/message - see
    references/blocked_asset_types.json, generated from
    mcp/security.py's BLOCKED_ASSET_TYPES). Mirrors the MCP server's own
    read-time gate so a generated script can't do what the MCP server
    refuses to."""
    blocked = _blocked_asset_types()
    if not blocked:
        print("[OK] Asset-type security check skipped (no security gate file bundled)")
        return

    violations = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            keyword_names = ASSET_TYPE_CONSTRUCTORS.get(node.func.id)
            if keyword_names is None:
                continue
            for kw in node.keywords:
                if (
                    kw.arg in keyword_names
                    and isinstance(kw.value, ast.Constant)
                    and isinstance(kw.value.value, str)
                    and kw.value.value.lower() in blocked
                ):
                    violations.append(
                        f"line {node.lineno}: {node.func.id}({kw.arg}={kw.value.value!r}) "
                        f"targets a blocked asset type."
                    )
        if isinstance(node, ast.Dict):
            keys = {
                k.value: v
                for k, v in zip(node.keys, node.values)
                if isinstance(k, ast.Constant) and isinstance(k.value, str)
            }
            asset_type_value = keys.get("asset_type")
            if (
                "path" in keys
                and isinstance(asset_type_value, ast.Constant)
                and isinstance(asset_type_value.value, str)
                and asset_type_value.value.lower() in blocked
            ):
                violations.append(
                    f"line {node.lineno}: Path dict (asset_type={asset_type_value.value!r}) "
                    f"targets a blocked asset type."
                )

    if violations:
        print("[SECURITY ERROR] Script targets a blocked asset type:")
        for v in violations:
            print(f"  - {v}")
        print(
            "  Access to users, groups, roles, and messages is restricted to protect "
            "confidential information. Ask the user to handle this part manually "
            "rather than through a generated script."
        )
        sys.exit(1)
    print("[OK] Asset-type security check passed")


# What each operation actually resolves to once parsed.
OPERATION_RESULT_TYPES = {
    "read": "Asset",
    "create": "IdentifierType",
    "edit": "CascadeSuccess",
    "delete": "CascadeSuccess",
    "copy": "CascadeSuccess",
    "move": "CascadeSuccess",
    "publish": "CascadeSuccess",
    "siteCopy": "CascadeSuccess",
    "checkIn": "CascadeSuccess",
    "checkOut": "CheckedOutAsset",
    "editAccessRights": "CascadeSuccess",
    "editWorkflowSettings": "CascadeSuccess",
    "editPreference": "CascadeSuccess",
    "markMessage": "CascadeSuccess",
    "deleteMessage": "CascadeSuccess",
    "performWorkflowTransition": "CascadeSuccess",
    "search": "ListElements",
    "listSites": "ListElements",
    "listMessages": "ListElements",
    "listSubscribers": "ListElements",
    "readAudits": "ListElements",
    "readAccessRights": "accessRightsInformationPayload",
    "readWorkflowSettings": "workflowSettingsPayload",
    "readWorkflowInformation": "workflowInformation",
    "readPreferences": "SimplePayload",
}


def check_result_type(tree: ast.Module):
    """Level 7: warn when submit_requests(T) disagrees with the operations
    actually queued. This is a type-hint-only argument, so a mismatch never
    fails at runtime — it just makes the script lie to its reader and to mypy."""
    queued = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            inner = node.func.value
            if isinstance(inner, ast.Attribute) and inner.attr == "operations":
                if node.func.attr in OPERATION_RESULT_TYPES:
                    queued.add(OPERATION_RESULT_TYPES[node.func.attr])

    warnings = []
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "submit_requests"
            and node.args
            and isinstance(node.args[0], ast.Name)
        ):
            hinted = node.args[0].id
            if queued and hinted not in queued:
                warnings.append(
                    f"line {node.lineno}: submit_requests({hinted}) but the queued "
                    f"operation(s) return {' | '.join(sorted(queued))}. "
                    f"Use submit_requests({sorted(queued)[0]}) or drop the hint."
                )

    for w in warnings:
        print(f"[WARN] {w}")
    print("[OK] Result-type check passed" + (" (with warnings)" if warnings else ""))


CONSTRUCTIBLE_NAMES = {
    "NewAsset", "IdentifierType", "deleteParameters", "copyParameters",
    "moveParameters", "publishInformation", "Comment", "SiteCopyParameter",
    "workflowTransitionInformation", "auditParameters", "SearchInformation",
    "preference", "Message", "accessRightsInformationPayload",
    "workflowSettingsPayload",
}


def check_construction(tree: ast.Module, source: str):
    """Level 8: find calls to known Pydantic payload/model classes and
    re-instantiate them with the literal args used in the script, so validation
    errors (missing required field, bad alias, wrong type) surface now instead
    of at runtime against a live Cascade server."""
    sys.path.insert(0, str(BUNDLED_PKG_PARENT))
    import cascade_cms.cmstypes as cmstypes

    constructible = {
        name: obj
        for name, obj in vars(cmstypes).items()
        if isinstance(obj, type) and name in CONSTRUCTIBLE_NAMES
    }

    errors = []
    checked = 0

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            cls_name = node.func.id
            if cls_name not in constructible:
                continue
            try:
                kwargs = {}
                skip = False
                for kw in node.keywords:
                    if kw.arg is None:
                        skip = True
                        break
                    try:
                        kwargs[kw.arg] = ast.literal_eval(kw.value)
                    except (ValueError, SyntaxError):
                        skip = True
                        break
                if skip or not kwargs:
                    continue
                checked += 1
                constructible[cls_name](**kwargs)
            except Exception as e:
                errors.append(f"{cls_name}(...) at line {node.lineno}: {e}")

    if errors:
        print(f"[CONSTRUCTION ERROR] {len(errors)} payload construction(s) failed validation:")
        for err in errors:
            print(f"  - {err}")
        print(f"  Fix: check field names and aliases in {field_reference()}.")
        sys.exit(1)
    print(f"[OK] Construction check passed — {checked} payload instantiation(s) validated")


def check_formatting(path: str) -> None:
    """Level 9: hard-fail if `ruff format` would reformat this script — 150-char
    lines, parenthesized multi-line chains over backslash continuation (see
    SKILL.md's "Formatting & readability"). Uses the skill's own ruff.toml
    explicitly so this behaves the same regardless of where the target script
    lives or where the validator is invoked from."""
    ruff = shutil.which("ruff")
    if ruff is None:
        print("[FORMAT] WARNING: ruff not found on PATH — skipping formatting check.")
        print("         Install it (`pip install ruff`) to enforce formatting locally.")
        return

    proc = subprocess.run(
        [ruff, "format", "--check", "--diff", "--config", str(RUFF_CONFIG_PATH), path],
        check=False,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        print("[FORMAT ERROR] ruff format would reformat this script:")
        print(proc.stdout + proc.stderr)
        print(f"  Fix: ruff format --config {RUFF_CONFIG_PATH} {path}")
        sys.exit(1)
    print("[OK] Formatting check passed")


def main():
    if len(sys.argv) != 2:
        print("Usage: python validate_script.py path/to/generated_script.py")
        sys.exit(2)

    path = sys.argv[1]
    source = Path(path).read_text()

    print_bundle_banner()
    tree = check_syntax(source, path)
    check_wrapper_only(tree, path)
    check_imports(tree, path)
    check_operation_names(tree)
    check_asset_subscript_assignment(tree)
    check_path_identifiers(tree)
    check_asset_type_security(tree)
    check_result_type(tree)
    check_construction(tree, source)
    check_formatting(path)

    print("\nAll static checks passed. No network calls were made.")


if __name__ == "__main__":
    main()
