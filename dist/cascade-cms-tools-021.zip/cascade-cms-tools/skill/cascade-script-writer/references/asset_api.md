# The `Asset` object

`Asset` is the result type of `read`. Unlike every other model in the library
it is **not** a Pydantic model — it is a thin wrapper around the raw
`{"asset": {"<type>": {...}}}` JSON, because Cascade's asset shape varies per
asset type. Nothing about its fields is schema-validated.

## Read and write

```python
asset.get("displayName")          # read  — dict-style .get(), with default
asset.displayName = "New Title"   # write — ATTRIBUTE assignment
asset.asset_type                  # "page", "file", "folder", ...
```

**Never `asset["displayName"] = value`.** `Asset` defines `__setattr__` and
`.get()`, and no `__setitem__` at all, so subscript assignment raises:

```python
asset["keywords"] = "x"
# TypeError: 'Asset' object does not support item assignment
```

Reading with `asset["keywords"]` fails the same way — there is no
`__getitem__` either. Use `.get()`.

## Type changes are rejected

`__setattr__` enforces that an existing field keeps its Python type:

```python
asset.name = "new-name"   # str -> str   OK
asset.name = 42           # str -> int   TypeError: Field 'name' has changed type
```

A field that is not already present is added without a type check. A field
whose current value is `None` has type `NoneType`, so assigning a `str` to it
raises — set it via the raw dict only if you know the server accepts it.

## Nothing is saved until you queue an edit

Mutating an `Asset` changes an in-memory object. To persist it:

```python
cascade.operations.edit(asset)          # or a list of assets
results = cascade.submit_requests(CascadeSuccess)
```

## Live references

Both accessors return **references into the asset**, so mutating what they
return mutates the asset itself:

```python
nodes = asset.get_data_structure("contact-block", "phone")
if nodes:
    for node in nodes:
        node["text"] = "+1 555 0100"    # asset is now modified

region = asset.get_page_configuration("ASPX", "FOOTER")
if region is not None:
    region.content = "<p>updated</p>"   # asset is now modified
```

- `get_data_structure(group, identifier)` → `list[dict] | None`. Searches all
  instances of the named group, returning the first matching node per instance.
- `get_page_configuration(name)` → `PageConfiguration | None`.
- `get_page_configuration(name, region)` → `PageRegion | None`.

Both return `None` when nothing matches — always guard before using the result.

**These are instance-sampling, leaf-only lookups, not schema discovery.**
`get_data_structure()` searches the *fields actually present on this one
asset instance* and returns leaf nodes — it does not tell you the full
schema-valid set of fields/groups the asset's content type allows, and its
result carries no reference to a node's parent group. See
`callback-structured-data-edit.py` for editing a matched node in place
(`update_contact`), renaming a node (`rename_node`), and moving a node to a
different parent group (`move_node`) — the latter two locate the node's
containing `structuredDataNodes` list directly, since `get_data_structure()`
itself never returns one. Do not confuse this with the MCP server's
similarly-named `cascade_get_data_structure` tool: that one is
schema-authoritative, resolving the asset's *bound content type/data
definition* to report the true valid field/group set, independent of what's
populated on any one instance. If the MCP server is connected, prefer it —
`cascade_get_data_structure` / `cascade_get_page_config` — to confirm valid
field/group/configuration names before writing a script that references them
by name, rather than guessing from this instance-sampling method. The MCP
server is read-only, though — writing structured data still goes through
this script-writing path.

## Errors come back as values

`read` returns a `CascadeError` instead of an `Asset` when the operation
fails; it does not raise. Check before touching asset fields:

```python
for result in cascade.submit_requests(Asset):
    if isinstance(result, CascadeError):
        print(f"failed: {result.message}")
        continue
    print(result.get("path"))
```
