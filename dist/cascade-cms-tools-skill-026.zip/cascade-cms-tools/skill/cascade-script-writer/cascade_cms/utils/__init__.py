"""Support modules: logging, token masking, and the `script_log` note facade."""

from .script_notes import script_log

__all__ = ["script_log"]
